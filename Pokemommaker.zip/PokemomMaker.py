import json
from grids import Grid

TEMPLATE_FILENAME = 'Drawing.txt'

grid = Grid()
XDIM = 20
YDIM = 20
grid.CreateGrid(XDIM, YDIM, ' ')
name = input('Enter name:\n>>')
main = {"Note": "Made with pokemommaker"}
hp = 0
while True:
    try:
        hp = round(int(input(f'Enter amount hp (btwn 10 and 25 recommended)\n>>')))
        break
    except: print("Enter a round number please")
DEF = 0
while True:
    try:
        DEF = round(int(input(f'Enter amount def (btwn 5 and 10 recommended)\n>>')))
        break
    except: print("Enter a round number please")

speed = 0
while True:
    try:
        speed = round(int(input(f'Enter amount speed (btwn 3 and 6 recommended)\n>>')))
        break
    except: print("Enter a round number please")

def getTemplateRaw() -> str:
    with open(TEMPLATE_FILENAME, 'r') as file:
        lines = ''
        for line in file:
            lines+=line
        return lines

def getTemplate() -> str:
    with open(TEMPLATE_FILENAME, 'r') as file:
        lines = ''
        for line in file:
            lines+=line.replace('\\', '\\\\').replace('\n', '\\n')
        return lines

def makeMoveset() -> dict:
    movesets = {}
    for x in range(4):
        temp = {}
        movename = input(f"Enter move {x+1}'s name:\n>>")
        slogan = input(f'Enter slogan of move: "{movename}" (text that appears in the textbox at the bottom)\n(use %name% for the name of the pokemom)\n(use %target% for the opponents name)\n>>')
        dmg = 0
        while True:
            try:
                dmg = round(int(input(f'Enter amount damage of {movename}\n>>')))
                break
            except: print("Enter a round number please")
        temp['slogan'] = slogan
        temp['DMG'] = dmg
        movesets[movename] = temp
    return movesets


def makeTemplate(name, LVL=1, template='',HP=15, ATT=5, SP_ATT=5, DEF=5, SP_DEF=5, SPEED=5, MOVESETS={}):
    moveSets = MOVESETS
    if len(moveSets) == 0:
        for x in range(4):
            moveSets[f'move{x+1}'] = {"slogan":'', 'SP_DMG':1, 'DMG':1}
    template = {'name':name,'template':template, 'moveset':moveSets,'HP':HP, 'LVL':LVL, 'items':[],'ATT':ATT, 'SP_ATT':SP_ATT, 'DEF':DEF, 'SP_DEF':SP_DEF, 'SPEED':SPEED}
    with open(f'{name}.json', 'w') as file:
        json.dump(template, file, indent=4)

def showTemplate(template, grid: Grid):
    posx = 0
    posy = YDIM-1
    for char in template:
        if char != '\n':
            grid.set(posx, posy, char)
            posx+=1
        else:
            posy-=1
            posx=0
    grid.ShowGrid()

moveset = makeMoveset()

print("This is your drawing/template:\n")

template = getTemplateRaw()
showTemplate(getTemplateRaw(), grid)

x = input('Want to continue? (y/n)\n>>')

if x == 'y':
    with open(f'{name}.json', 'w') as file:
        makeTemplate(name, template=template, DEF=DEF, MOVESETS=moveset, SPEED=speed)
    print(f"Done! Put the '{name}.json' in your pokemom folder and enjoy!")
else:
    print("Canceled!")


